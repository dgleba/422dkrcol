<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "position": 1,
    "label": "About",
    "text": "This is a brief description of yourself or your site, to change this text go to the admin panel, settings, plugins, and configure the plugin about."
}