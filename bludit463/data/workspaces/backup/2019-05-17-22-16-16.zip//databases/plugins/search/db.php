<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "label": "Search",
    "wordsToCachePerPage": 800,
    "showButtonSearch": false,
    "position": 0
}