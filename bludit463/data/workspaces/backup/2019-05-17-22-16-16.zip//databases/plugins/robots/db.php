<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "position": 1,
    "robotstxt": "User-agent: *\nAllow: \/"
}