<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "admin": {
        "nickname": "Admin",
        "firstName": "Administrator",
        "lastName": "",
        "role": "admin",
        "password": "a7d85a56038f57333fa84e2dd2691de4e0533030",
        "salt": "5cdf5fce92d7b",
        "email": "",
        "registered": "2019-05-17 21:28:46",
        "tokenRemember": "",
        "tokenAuth": "49322487dbb6a5bbffa9cdbe88b45c43",
        "tokenAuthTTL": "2009-03-15 14:00",
        "twitter": "",
        "facebook": "",
        "instagram": "",
        "codepen": "",
        "linkedin": "",
        "github": "",
        "gitlab": ""
    }
}