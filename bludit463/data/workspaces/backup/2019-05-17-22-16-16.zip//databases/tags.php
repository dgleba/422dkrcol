<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "bludit": {
        "name": "Bludit",
        "description": "",
        "template": "",
        "list": [
            "follow-bludit"
        ]
    },
    "cms": {
        "name": "CMS",
        "description": "",
        "template": "",
        "list": [
            "follow-bludit"
        ]
    },
    "flat-files": {
        "name": "Flat files",
        "description": "",
        "template": "",
        "list": [
            "follow-bludit"
        ]
    }
}