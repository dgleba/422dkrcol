<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
{
    "general": {
        "name": "General",
        "description": "",
        "template": "",
        "list": [
            "example-page-1-slug",
            "example-page-2-slug",
            "example-page-3-slug",
            "example-page-4-slug"
        ]
    },
    "music": {
        "name": "Music",
        "description": "",
        "template": "",
        "list": []
    },
    "videos": {
        "name": "Videos",
        "description": "",
        "template": "",
        "list": []
    }
}