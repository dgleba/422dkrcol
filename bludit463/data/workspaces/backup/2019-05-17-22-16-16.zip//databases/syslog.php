<?php defined('BLUDIT') or die('Bludit CMS.'); ?>
[
    {
        "date": "2019-05-17 22:16:16",
        "dictionaryKey": "plugin-configured",
        "notes": "Backup",
        "idExecution": "5cdf6af0465bc",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2019-05-17 22:16:13",
        "dictionaryKey": "plugin-activated",
        "notes": "Backup",
        "idExecution": "5cdf6aed7dafd",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2019-05-17 21:53:54",
        "dictionaryKey": "plugin-configured",
        "notes": "Search",
        "idExecution": "5cdf65b255861",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2019-05-17 21:52:57",
        "dictionaryKey": "plugin-configured",
        "notes": "SimpleMDE",
        "idExecution": "5cdf65798cec5",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2019-05-17 21:52:54",
        "dictionaryKey": "plugin-activated",
        "notes": "SimpleMDE",
        "idExecution": "5cdf65765aa11",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2019-05-17 21:52:43",
        "dictionaryKey": "plugin-deactivated",
        "notes": "TinyMCE",
        "idExecution": "5cdf656bb6ddc",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2019-05-17 21:51:19",
        "dictionaryKey": "plugin-configured",
        "notes": "Search",
        "idExecution": "5cdf6517b1c3a",
        "method": "POST",
        "username": "admin"
    },
    {
        "date": "2019-05-17 21:51:10",
        "dictionaryKey": "plugin-activated",
        "notes": "Search",
        "idExecution": "5cdf650ecb120",
        "method": "GET",
        "username": "admin"
    },
    {
        "date": "2019-05-17 21:28:46",
        "dictionaryKey": "welcome-to-bludit",
        "notes": "",
        "idExecution": "5cdf5fce92de4",
        "method": "POST",
        "username": "admin"
    }
]